Pocket Windows 11 Android 프로젝트 v1.0

포함 기능:
- Windows 11 스타일 데스크톱 및 시작 메뉴
- 터치 조작, 길게 눌러 컨텍스트 메뉴
- 앱 창 열기/닫기/최소화/최대화/드래그 이동
- 앱 내부 파일 탐색기(폴더/텍스트 파일 생성, 이름 변경, 삭제, 휴지통/복원)
- 메모장, 계산기, 설정, 브라우저(외부 브라우저 열기), 사진 가져오기
- 데이터는 앱 내부 저장소(localStorage)에 저장

APK 빌드:
1. Android Studio에서 이 프로젝트 폴더를 엽니다.
2. Gradle 동기화가 끝날 때까지 기다립니다.
3. Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
4. APK 위치: app/build/outputs/apk/debug/app-debug.apk

주의:
이 앱은 실제 Microsoft Windows 11 운영체제나 Windows용 .exe 실행기가 아닙니다.
Windows 11의 시각적 디자인을 참고한 독립 Android 앱입니다.
파일 탐색기는 휴대폰 전체 파일 시스템이 아닌 앱 내부의 가상 파일 공간을 관리합니다.
브라우저는 안전을 위해 외부 브라우저로 사이트를 엽니다.
